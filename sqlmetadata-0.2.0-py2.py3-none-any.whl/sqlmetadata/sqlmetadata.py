
from typing import List, Dict, Any, Union
import sys
import logging
import json

from sqlglot import parse_one, parse, exp, Expression
from sqlglot.lineage import lineage, Node

LOGGER = logging.getLogger(__name__)


class SQLParseException(Exception):
    def __init__(self, e:Exception):
        super().__init__(e.message)

class SQLMetadata():

    SELECT_FQ_TABLE_NAME = '__SELECT__'

    def extract_sql_statements_lineage(sql_stmt: str,
                                        dialect: str = None) -> Dict[Any,Dict[Any,Any]]:

        sql_statements_column_lineage = {}

        statements = None
        try:
            statements = parse(sql_stmt, read=dialect)
        except Exception as e:
            raise SQLParseException(e)

        if statements:
            for statement in statements:
                stmt_col_lineage = SQLMetadata.extract_column_lineage(
                    sql_stmt=statement.sql(dialect=dialect),
                    dialect=dialect,
                    sql_statements_column_lineage=sql_statements_column_lineage
                )

                if stmt_col_lineage:
                    sql_statements_column_lineage.update(stmt_col_lineage)

        return sql_statements_column_lineage

    def extract_column_lineage(sql_stmt: str,
                               dialect: str = None,
                               sql_statements_column_lineage: Dict[str,Dict[Any,Any]] = None) -> Dict[Any,Any]:

        ast = None
        try:
            ast = parse_one(sql_stmt, read=dialect)
        except Exception as e:
            raise SQLParseException(e)

        if ast:
            try:
                sql_stmt_lineage = {}

                # if isinstance(ast, exp.Union):
                #     # If the ast is a Union[All]...
                #     # Find the first select
                #     def get_union_selects(union: exp.Union) -> List[exp.Select]:
                #         _union_selects = []

                #         if union.left:
                #             if isinstance(union.left, exp.Union):
                #                 left_union_selects = get_union_selects(union=union.left)
                #                 _union_selects.extend(left_union_selects)
                #             elif isinstance(union.left, exp.Select):
                #                 _union_selects.append(union.left)

                #         if union.right:
                #             if isinstance(union.right, exp.Select):
                #                 _union_selects.append(union.right)
                #             elif isinstance(union.right, exp.Union):
                #                 right_union_selects = get_union_selects(union=union.right)
                #                 _union_selects.extend(right_union_selects)

                #         return _union_selects

                #     union_selects = get_union_selects(ast)
                #     left_select = union_selects[0]
                #     column_lineage = SQLMetadata._process_select(select=left_select, sql_stmt=sql_stmt, dialect=dialect)
                # else:
                fq_table_name = None
                if isinstance(ast, exp.Create) and ast.kind.lower() == 'table':
                    table = ast.find(exp.Table)
                    if table:
                        fq_table_name, schema_name, table_name = SQLMetadata._get_fq_table_name(table)

                        sql_stmt_lineage[fq_table_name] = {}
                        sql_stmt_lineage[fq_table_name]['statements'] = [sql_stmt]
                        sql_stmt_lineage[fq_table_name]['schema'] = schema_name
                        sql_stmt_lineage[fq_table_name]['table'] = table_name

                        column_defs = ast.find_all(exp.ColumnDef)
                        if column_defs:
                            columns = {}
                            for column_def in column_defs:
                                column_name = column_def.name.lower()
                                columns[column_name] = {}
                                columns[column_name]['data_type'] = column_def.kind.this.name
                            sql_stmt_lineage[fq_table_name]['columns'] = columns

                    else:
                        LOGGER.warning(f'Found CREATE statement of kind TABLE, but could not find a table:\n{ast.sql(dialect=dialect)}')

                # Get the select for lineage
                final_select = ast.find(exp.Select)

                if final_select:
                    column_lineage = SQLMetadata._process_select(select=final_select, sql_stmt=sql_stmt, dialect=dialect)
                    if column_lineage:
                        if fq_table_name:
                            sql_stmt_lineage[fq_table_name]['columns'] = column_lineage
                        elif isinstance(ast, exp.Insert):
                            table = ast.find(exp.Table)
                            if table:
                                fq_table_name, schema_name, table_name = SQLMetadata._get_fq_table_name(table)

                                sql_stmt_lineage[fq_table_name] = {}
                                _sql_stmt_lineage = sql_statements_column_lineage.get(fq_table_name)

                                if not _sql_stmt_lineage:
                                    sql_stmt_lineage[fq_table_name]['schema'] = schema_name
                                    sql_stmt_lineage[fq_table_name]['table'] = table_name
                                    sql_stmt_lineage[fq_table_name]['statements'] = []
                                else:
                                    sql_stmt_lineage[fq_table_name] = _sql_stmt_lineage

                                sql_stmt_lineage[fq_table_name]['statements'].append(sql_stmt)
                                if sql_stmt_lineage[fq_table_name]['columns']:
                                    columns = {}
                                    for column_name, column_details in column_lineage.items():
                                        columns[column_name] = {**sql_stmt_lineage[fq_table_name]['columns'][column_name], **column_details}
                                    for column_name, column_details in sql_stmt_lineage[fq_table_name]['columns'].items():
                                        if column_name not in columns:
                                            columns[column_name] = column_details
                                    sql_stmt_lineage[fq_table_name]['columns'] = columns
                                else:
                                    sql_stmt_lineage[fq_table_name]['columns'] = column_lineage
                            else:
                                LOGGER.warning(f'Found INSERT statement but cannot find Table\n{ast.sql(dialect=dialect)}')
                        elif isinstance(ast, exp.Select) or isinstance(ast, exp.With):
                            fq_table_name = SQLMetadata.SELECT_FQ_TABLE_NAME
                            if sql_statements_column_lineage.get(fq_table_name):
                                LOGGER.warning(f'Main SELECT already found:\n{sql_statements_column_lineage.get(fq_table_name)}\n\nSkipping this one:\n{sql_stmt}')
                            else:
                                sql_stmt_lineage[fq_table_name] = {}
                                sql_stmt_lineage[fq_table_name]['statements'] = [sql_stmt]
                                sql_stmt_lineage[fq_table_name]['columns'] = column_lineage
                        else:
                            LOGGER.warning(f'Unhandled expression type\n{ast}')

                else:
                    LOGGER.info(f"No SELECT stmt found:\n{ast}")

                return sql_stmt_lineage

            except Exception as e:
                raise e

    def _get_fq_table_name(table: exp.Table) -> str:
        schema_name = table.db.lower() if table.db and table.db != '' else None
        table_name = table.name.lower()
        fq_table_name = f"{schema_name if schema_name else ''}{'.' if schema_name else ''}{table_name}"
        return fq_table_name, schema_name, table_name

    ########################

    def _generate_source_column_str(source_db_name: str,
                                    source_table_name: str,
                                    source_column_name: str,
                                    expression: str = None) -> str:
        return f'{source_db_name.lower()}.{source_table_name.lower()}/{source_column_name.lower()}{f" /* {expression} */" if expression else ""}'

    def _table_column_lineage_dict(
        source_db_name: str = None,
        source_table_name: str = None,
        source_column_name: str = None,
        expression: Expression = None,
        message: str = None) -> Dict[Any,Any]:

        filter_type = None
        filter = None
        if expression and \
            isinstance(expression, exp.Table) and \
            isinstance(expression.parent, exp.Join):

            filter_type = expression.parent.args.get("kind")+" JOIN" if expression.parent.args.get('kind') else "JOIN"
            filter = expression.parent.args.get('on')
        elif expression and \
            isinstance(expression, exp.Table) and \
            isinstance(expression.parent, exp.From):

            filter_type = 'WHERE' if expression.parent_select.args.get('where') else 'UNKNOWN'
            filter = expression.parent_select.args.get('where')

        return {
            "schema": source_db_name.lower() if source_db_name else None,
            "table": source_table_name.lower() if source_table_name else None,
            "column": source_column_name.lower() if source_column_name else None,
            "expression": f'{expression}',
            "filter_type": filter_type,
            "filter": f'{filter}' if filter else None,
            "message": message
        }

    def _lineage_dict(expression: str = None, lineage_items: List[Any] = None) -> Dict[Any,Any]:
        return {
            "expression": expression,
            "lineage":lineage_items
        }

    def _find_source_table_column(node: Node, parent_node: Node = None) -> List[Any]:

        def _find_source_table_column_from_exp(node: Node):
            col_lineage = None

            if isinstance(node.expression, exp.Table):
                source_db_name = node.expression.args['db'].alias_or_name if node.expression.args.get('db') else None
                source_table_name = node.expression.this.name
                source_column_name = node.name.split('.')[-1]

                col_lineage = SQLMetadata._table_column_lineage_dict(
                    source_db_name=source_db_name,
                    source_table_name=source_table_name,
                    source_column_name=source_column_name,
                    expression=node.expression,
                    message=f'Table'
                )
            elif isinstance(node.expression, exp.Alias):
                if isinstance(node.expression.this, exp.Column):
                    source_column_name = node.expression.this.alias_or_name.lower()
                    source_column_table_alias = node.expression.this.table.lower()

                    def find_column_lineage_by_table_alias(select: exp.Select, column_name: str, table_alias: str) -> Dict[Any,Any]:
                        expr_tables = select.find_all(exp.Table)
                        for table in expr_tables:
                            if table.alias.lower() == source_column_table_alias or table.name.lower() == source_column_table_alias:
                                return SQLMetadata._table_column_lineage_dict(
                                    source_db_name=table.db,
                                    source_table_name=table.name,
                                    source_column_name=column_name,
                                    expression=node.expression,
                                    message=f'Column Alias'
                                )

                        return None

                    table_alias_col_lineage = find_column_lineage_by_table_alias(
                        select=node.expression.parent_select,
                        column_name=source_column_name,
                        table_alias=source_column_table_alias
                    )

                    if table_alias_col_lineage:
                        col_lineage = table_alias_col_lineage
                    else:
                        # Didn't find any lineage, try the TableAlias, which can map to things like Pivots
                        parent_select_table_aliases = node.expression.parent_select.find_all(exp.TableAlias)
                        for table_alias in parent_select_table_aliases:
                            if table_alias.alias_or_name.lower() == source_column_table_alias:
                                if isinstance(table_alias.parent, exp.Table):
                                    col_lineage = SQLMetadata._table_column_lineage_dict(
                                        source_db_name=table_alias.parent.db,
                                        source_table_name=table_alias.parent.name,
                                        source_column_name=source_column_name,
                                        expression=node.expression,
                                        message=f'Table Alias'
                                    )
                                else:
                                    LOGGER.warning(f"Column Alias {source_column_table_alias}.{source_column_name} is tied to a non-table:\n{table_alias.parent}")
                                    parent_select_aliases = node.expression.parent_select.find_all(exp.Alias)
                                    for alias in parent_select_aliases:
                                        if alias != node.expression and alias.alias.lower() == source_column_name and isinstance(alias.this, exp.Column):
                                            # Found source column name as an alias of a column in the select.
                                            source_column_table_alias = alias.this.table.lower()

                                            table_alias_col_lineage = find_column_lineage_by_table_alias(
                                                select=node.expression.parent_select,
                                                column_name=source_column_name,
                                                table_alias=source_column_table_alias
                                            )

                                            if table_alias_col_lineage:
                                                col_lineage = table_alias_col_lineage
                                                break
                                break
                elif isinstance(node.expression.this, exp.Null):
                    col_lineage = SQLMetadata._table_column_lineage_dict(
                        expression=node.expression,
                        message=f"Null"
                    )
                else:
                    source_column_select_from_table = node.expression.parent_select.args['from'].this
                    col_lineage = SQLMetadata._table_column_lineage_dict(
                        source_db_name=source_column_select_from_table.db,
                        source_table_name=source_column_select_from_table.name,
                        source_column_name=node.expression.alias_or_name,
                        expression=node.expression,
                        message=f"Alias"
                    )
            elif isinstance(node.expression, exp.Placeholder):
                LOGGER.info(f'Downstream is Ambiguous (Placeholder), trying the parent node even though it has downstream:\n{node}')
                parent_node_col_lineage = _find_source_table_column_from_exp(node=parent_node)
                if parent_node_col_lineage:
                    parent_node_col_lineage['message'] = f'{parent_node_col_lineage["message"]} - Ambiguous'
                    col_lineage = parent_node_col_lineage
                else:
                    col_lineage = SQLMetadata._table_column_lineage_dict(
                        source_column_name=node.name,
                        expression=node.expression,
                        message="Ambiguous"
                    )
                    col_lineage['expression'] = node.name
            else:
                LOGGER.warning(f"Found most downstream node, but it's not currently supported: \n{node}")

            return col_lineage

        ###############
        col_lineage = set()

        if node.downstream and len(node.downstream) > 0:

            for downstream in node.downstream:
                downstream_col_lineage = SQLMetadata._find_source_table_column(node=downstream, parent_node=node) or []
                for downstream_col_lineage_dict in downstream_col_lineage:
                    col_lineage.add(tuple(downstream_col_lineage_dict.items()))

        else:

            col_lineage.add(tuple(_find_source_table_column_from_exp(node=node).items()))

            if isinstance(node.expression, exp.Table):

                source_db_name = node.expression.args['db'].alias_or_name if node.expression.args.get('db') else None
                source_table_name = node.expression.this.name
                source_column_name = node.name.split('.')[-1]

                col_lineage.add(tuple(SQLMetadata._table_column_lineage_dict(
                        source_db_name=source_db_name,
                        source_table_name=source_table_name,
                        source_column_name=source_column_name,
                        expression=node.expression,
                        message=f'Table'
                    ).items())
                )

            elif isinstance(node.expression, exp.Alias):

                if isinstance(node.expression.this, exp.Column):

                    source_column_name = node.expression.this.alias_or_name.lower()
                    source_column_table_alias = node.expression.this.table.lower()

                    def find_column_lineage_by_table_alias(select: exp.Select, column_name: str, table_alias: str) -> Dict[Any,Any]:

                        expr_tables = select.find_all(exp.Table)
                        for table in expr_tables:
                            if table.alias.lower() == source_column_table_alias or table.name.lower() == source_column_table_alias:
                                return SQLMetadata._table_column_lineage_dict(
                                    source_db_name=table.db,
                                    source_table_name=table.name,
                                    source_column_name=column_name,
                                    expression=node.expression,
                                    message=f'Column Alias'
                                )

                        return None

                    table_alias_col_lineage = find_column_lineage_by_table_alias(
                        select=node.expression.parent_select,
                        column_name=source_column_name,
                        table_alias=source_column_table_alias
                    )

                    if table_alias_col_lineage:
                        col_lineage.add(tuple(table_alias_col_lineage).items())
                    else:
                        # Didn't find any lineage, try the TableAlias, which can map to things like Pivots
                        parent_select_table_aliases = node.expression.parent_select.find_all(exp.TableAlias)
                        for table_alias in parent_select_table_aliases:
                            if table_alias.alias_or_name.lower() == source_column_table_alias:
                                if isinstance(table_alias.parent, exp.Table):
                                    col_lineage.add(tuple(SQLMetadata._table_column_lineage_dict(
                                            source_db_name=table_alias.parent.db,
                                            source_table_name=table_alias.parent.name,
                                            source_column_name=source_column_name,
                                            expression=node.expression,
                                            message=f'Column Alias'
                                        ).items())
                                    )
                                else:
                                    LOGGER.warning(f"Column Alias {source_column_table_alias}.{source_column_name} is tied to a non-table:\n{table_alias.parent}")
                                    parent_select_aliases = node.expression.parent_select.find_all(exp.Alias)
                                    for alias in parent_select_aliases:
                                        if alias != node.expression and alias.alias.lower() == source_column_name and isinstance(alias.this, exp.Column):
                                            # Found source column name as an alias of a column in the select.
                                            source_column_table_alias = alias.this.table.lower()

                                            table_alias_col_lineage = find_column_lineage_by_table_alias(
                                                select=node.expression.parent_select,
                                                column_name=source_column_name,
                                                table_alias=source_column_table_alias
                                            )
                                            if table_alias_col_lineage:
                                                col_lineage.add(tuple(table_alias_col_lineage))
                                                break
                                break
                elif isinstance(node.expression.this, exp.Null):
                    col_lineage.add(tuple(SQLMetadata._table_column_lineage_dict(
                            expression=node.expression,
                            message=f"Null"
                        ).items())
                    )
                else:
                    source_column_select_from_table = node.expression.parent_select.args['from'].this
                    col_lineage.add(tuple(SQLMetadata._table_column_lineage_dict(
                            source_db_name=source_column_select_from_table.db,
                            source_table_name=source_column_select_from_table.name,
                            source_column_name=node.expression.alias_or_name,
                            expression=node.expression,
                            message=f"Alias"
                        ).items())
                    )
            elif isinstance(node.expression, exp.Placeholder):
                LOGGER.info(f'Downstream is Ambiguous (Placeholder), trying the parent node even though it has downstream:\n{node}')
                table_col_lineage_dict = SQLMetadata._table_column_lineage_dict(
                    source_column_name=node.name,
                    expression=node.expression,
                    message="Ambiguous"
                )
                table_col_lineage_dict['expression'] = node.name

                col_lineage.add(tuple(table_col_lineage_dict.items()))
            else:
                LOGGER.warning(f"Found most downstream node, but it's not currently supported: \n{node}")

        return [dict(item) for item in col_lineage]

    def _find_columns(expr: exp.Expression) -> exp.Column:
        columns = []

        for arg in expr.args:
            arg_val = expr.args[arg]
            if arg_val:
                if isinstance(arg_val, List):
                    for item in arg_val:
                        if isinstance(item, exp.Column):
                            columns.append(item)
                        elif isinstance(item, exp.Expression):
                            columns.extend(SQLMetadata._find_columns(item))
                elif isinstance(arg_val, exp.Column):
                    columns.append(arg_val)
                elif isinstance(arg_val, exp.Expression):
                    columns.extend(SQLMetadata._find_columns(arg_val))
        return columns

    def _extract_column_lineage(column: Union[exp.Column,str],
                                sql_stmt: str,
                                dialect: str) -> List[Dict[Any,Any]]:
        try:

            col_node = lineage(column=column,
                                sql=sql_stmt,
                                dialect=dialect)
            col_lineage = SQLMetadata._find_source_table_column(node=col_node)


            return col_lineage

        except Exception as e:
            raise e



    def _process_select(select: exp.Select,
                        sql_stmt: str,
                        dialect: str = None) -> Dict[Any,Any]:

        table_columns_lineage = None

        if select:

            table_columns_lineage = {}

            for expression in select.expressions:

                if isinstance(expression, exp.Star) and \
                   select.args.get('from') and \
                   isinstance(select.args.get('from').this, exp.Subquery):

                    table_columns_lineage = table_columns_lineage | \
                        SQLMetadata._process_select(
                            select=select.args.get('from').this.this,
                            sql_stmt=sql_stmt, dialect=dialect
                        )

                elif isinstance(expression, exp.Column):

                    try:
                        col_name = expression.alias_or_name.lower()

                        col_lineage = SQLMetadata._extract_column_lineage(
                            column=expression,
                            sql_stmt=sql_stmt,
                            dialect=dialect
                        )

                        table_columns_lineage[col_name] = SQLMetadata._lineage_dict(
                            expression=f"{expression}",
                            lineage_items=col_lineage
                        )

                    except Exception as e:
                        LOGGER.exception(f'Failed to find lineage for column: \n{expression}')

                        # Check if it's a * column
                        if isinstance(expression.this, exp.Star):
                            star_column_table_ns = expression.args['table'].alias_or_name

                            if select.args.get('from') and select.args.get('from').alias_or_name.lower() == star_column_table_ns.lower():

                                if isinstance(select.args.get('from').this, exp.Subquery):

                                    subquery_select = select.args.get('from').this.this
                                    sq_table_columns_lineage = SQLMetadata._process_select(select=subquery_select, sql_stmt=sql_stmt, dialect=dialect)
                                    if sq_table_columns_lineage is not None:
                                        LOGGER.info(f"Was able to find lineage from subquery:\n{sq_table_columns_lineage}")
                                    table_columns_lineage = table_columns_lineage | (sq_table_columns_lineage or {})

                elif isinstance(expression, exp.Alias):

                    col_name = expression.alias_or_name.lower()

                    if isinstance(expression.this, exp.Column):

                        col_lineage = SQLMetadata._extract_column_lineage(
                            column=expression.alias_or_name,
                            sql_stmt=sql_stmt,
                            dialect=dialect
                        )
                        table_columns_lineage[col_name] = SQLMetadata._lineage_dict(
                            expression=f"{expression}",
                            lineage_items=col_lineage
                        )

                    elif isinstance(expression.this, exp.Literal):

                        col_lineage = [SQLMetadata._table_column_lineage_dict(
                                expression=expression,
                                message=f"Literal"
                            )
                        ]
                        table_columns_lineage[col_name] = SQLMetadata._lineage_dict(
                            expression=f"{expression}",
                            lineage_items=col_lineage
                        )

                    else:


                        columns_lineage = []
                        column_exprs = SQLMetadata._find_columns(expr=expression.this)
                        for column in column_exprs:
                            try:

                                col_lineage = SQLMetadata._extract_column_lineage(
                                    column=column,
                                    sql_stmt=sql_stmt,
                                    dialect=dialect
                                )

                                columns_lineage.extend(col_lineage)

                            except Exception as e:
                                LOGGER.exception(f'Failed to find lineage for alias column: \n{expression.this}')

                                source_db_name = None
                                source_table_name = None
                                _source_table_name = column.args['table'].alias_or_name if column.args.get('table') else None
                                source_column_name = column.this.alias_or_name
                                _source_table = None
                                message = "Complex expression.  Manually found lineage."

                                select_tables = select.find_all(exp.Table)
                                if select_tables and _source_table_name:
                                    for table in select_tables:
                                        if table.alias_or_name.lower() == _source_table_name.lower():
                                            _source_table = table
                                            source_db_name = table.db
                                            source_table_name = table.name
                                            break
                                elif select_tables:
                                    _source_table = next(select_tables)
                                    if _source_table:
                                        source_db_name = _source_table.db if _source_table.db and _source_table.db != '' else None
                                        source_table_name = _source_table.name

                                if source_table_name is None or source_column_name is None:
                                    message = "COULD NOT FIND COMPLETE SOURCE db.table/column"

                                _lineage = SQLMetadata._table_column_lineage_dict(
                                    source_db_name=source_db_name,
                                    source_table_name=source_table_name,
                                    source_column_name=source_column_name,
                                    expression=_source_table,
                                    message=message
                                )
                                if source_db_name is not None and source_table_name is not None and source_column_name is not None:
                                    LOGGER.info(f'Was able to find lineage manually: \n{_lineage}')

                                columns_lineage.append(_lineage)

                        table_columns_lineage[col_name] = SQLMetadata._lineage_dict(
                            expression=f"{expression}",
                            lineage_items=columns_lineage
                        )

        return table_columns_lineage

if __name__ == "__main__":
    # Create a formatter and set it for the handler
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # Create a handler that logs to stdout
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)
    handler.setFormatter(formatter)

    LOGGER = logging.getLogger(__name__)
    LOGGER.setLevel(logging.INFO)
    LOGGER.addHandler(handler)

    def test_client() -> str:
        return """
            -- Set the schema search path
            SET search_path TO public;

            -- Drop a table if it exists
            DROP TABLE IF EXISTS users;

            -- Create a new table
            CREATE TABLE users (
                id SERIAL PRIMARY KEY,
                username VARCHAR(50) NOT NULL,
                email VARCHAR(100) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            -- Create another table and insert data into it using a SELECT statement
            CREATE TABLE active_users AS
            SELECT id, username, email
            FROM users
            WHERE created_at > CURRENT_DATE - INTERVAL '30 days';

            -- Insert data into users from another table or a select query
            INSERT INTO users (username, email)
            SELECT username, email
            FROM old_users
            WHERE active = true;

            -- Drop database if it exists
            DROP DATABASE IF EXISTS archive_db;

            -- Create a new database
            CREATE DATABASE archive_db;

            -- Use a conditional expression in a select query
            SELECT
                id,
                username,
                CASE
                    WHEN created_at > CURRENT_DATE - INTERVAL '30 days' THEN 'recent'
                    ELSE 'older'
                END AS account_status
            FROM users;
        """, \
            'postgres'

    def test_hive() -> str:
        return """
            -- Set some Hive configurations
            SET hive.exec.dynamic.partition = true;
            SET hive.exec.dynamic.partition.mode = nonstrict;

            -- Drop tables if they exist
            DROP TABLE IF EXISTS employees;
            DROP TABLE IF EXISTS departments;
            DROP TABLE IF EXISTS high_salary_employees;

            -- Create the employees table
            CREATE TABLE employees (
                emp_id INT,
                name STRING,
                age INT,
                department_id INT,
                salary FLOAT
            )
            ROW FORMAT DELIMITED
            FIELDS TERMINATED BY ',';

            -- Create the departments table
            CREATE TABLE departments (
                dept_id INT,
                dept_name STRING
            )
            ROW FORMAT DELIMITED
            FIELDS TERMINATED BY ',';

            -- Insert some sample data into employees
            INSERT INTO TABLE employees
            SELECT emp_id, name, age, department_id, salary
            FROM legacy_employees
            WHERE active = true;


            -- Insert some sample data into departments
            INSERT INTO TABLE departments VALUES
            (101, 'Engineering'),
            (102, 'Marketing'),
            (103, 'Sales');

            -- Create a table to store high-salary employees
            CREATE TABLE high_salary_employees AS
            SELECT e.emp_id, e.name, e.salary, d.dept_name
            FROM employees e
            JOIN departments d ON e.department_id = d.dept_id
            WHERE e.salary > 60000;

            -- Final SELECT statement with CASE and WHERE clause
            SELECT
                e.emp_id,
                e.name,
                e.salary,
                d.dept_name,
                CASE
                    WHEN e.salary > 80000 THEN 'High'
                    WHEN e.salary BETWEEN 50000 AND 80000 THEN 'Medium'
                    ELSE 'Low'
                END AS salary_category
            FROM employees e
            JOIN departments d ON e.department_id = d.dept_id
            WHERE e.age > 25
            ORDER BY e.salary DESC;
        """, 'hive'

    def test_complex() -> str:
        return """
        -- Set the schema search path
        SET search_path TO public;

        -- Drop a table if it exists
        DROP TABLE IF EXISTS users;

        -- Create a new table
        CREATE TABLE users (
            id SERIAL PRIMARY KEY,
            username VARCHAR(50) NOT NULL,
            email VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Create another table and insert data into it using a SELECT statement
        CREATE TABLE active_users AS
        SELECT id, username, email
        FROM users
        WHERE created_at > CURRENT_DATE - INTERVAL '30 days';

        -- Insert data into users from another table or a select query
        INSERT INTO users (username, email)
        SELECT username, email
        FROM old_users
        WHERE active = true;

        -- Drop database if it exists
        DROP DATABASE IF EXISTS archive_db;

        -- Create a new database
        CREATE DATABASE archive_db;

        -- Use a conditional expression in a select query
        SELECT
            u.id,
            u.username as username,
            au.username as active_username,
            CASE
                WHEN u.created_at > CURRENT_DATE - INTERVAL '30 days' and au.created_at < CURRENT_DATE THEN 'recent'
                ELSE 'older'
            END AS account_status
        FROM users u
        INNER JOIN active_users au on
            au.id = u.id and
            au.created_at > CURRENT_DATE
        WHERE u.username = 'test';
    """, 'postgres'

    def test_union() -> str:

        return """
    SELECT
        col_1,
        col_2,
        col_3
    FROM
        table_1
    UNION
    SELECT
        col_1,
        col_2,
        col_3
    FROM
        table_2
        """, 'oracle'



    #####################
    # sql_stmt, dialect = test_complex()
    # sql_stmt, dialect = test_hive()
    sql_stmt, dialect = test_client()

    lineage_str = json.dumps(
        SQLMetadata.extract_sql_statements_lineage(
            sql_stmt=sql_stmt,
            dialect=dialect
        ),
        indent=2
    )

    LOGGER.info(lineage_str)